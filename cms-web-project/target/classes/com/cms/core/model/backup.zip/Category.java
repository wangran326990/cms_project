package com.cms.core.model;

public class Category {
	
}
