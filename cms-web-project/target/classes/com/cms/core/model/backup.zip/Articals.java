package com.cms.core.model;

public class Articals {

}
