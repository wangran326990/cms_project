package com.cms.core.model;

public enum RoleType {
	ROLE_ADMIN,
	ROLE_PUBLISHER,
	ROLE_AUDIT
}
